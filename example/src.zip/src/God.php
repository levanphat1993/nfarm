<?php

namespace Src;

class God 
{
    public function getTime(): int
    {
        return time();
    }

    public function getYesterdayDate(): string
    {
        return date("F j, Y", time() - 60 * 60 * 24);
    }

    public function getDaysInMonth(): int
    {
        return cal_days_in_month(CAL_GREGORIAN, date('m'), date('Y'));
    }

    public function isCacheWritable(): bool
    {
        return is_writable(CACHE_FILE);
    }

    public function writeToCache($data): bool
    {
        return (file_put_contents(CACHE_FILE, $data) !== false);
    }

    public function whatIsThisClass(): string
    {
        return "Pure technical debt in the form of a God Class.";
    }
}

class Watch
{
    public function getTime(): int
    {
        return time();
    }

    public function getYesterdayDate(): string
    {
        return date("F j, Y", time() - 60 * 60 * 24);
    }

    public function getDaysInMonth(): int
    {
        return cal_days_in_month(CAL_GREGORIAN, date('m'), date('Y'));
    }
}

class CacheManager
{
    public function isCacheWritable(): bool
    {
        return is_writable(CACHE_FILE);
    }
    
    public function writeToCache($data): bool
    {
        return (file_put_contents(CACHE_FILE, $data) !== false);
    }
}