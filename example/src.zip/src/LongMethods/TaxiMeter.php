<?php


class TaxiMeter
{

    const MIN_RATE = 2.50;
    const secondsInDay = 60 * 60 * 24;
    const MILE_RATE = 0.2;
    const SECONDS_IN_DAY = '';

    private $timeOfDay;
    private $baseRate;
    private $miles;
    private $dob;

    public function __construct(int $timeOfDay, float $baseRate, string $driverDateOfBirth)
    {
        if ($timeOfDay > self::SECONDS_IN_DAY) {
            throw new Exception('There can only be ' . self::SECONDS_IN_DAY . 'seconds in a day.');
        } else if ($timeOfDay < 0) {
            throw new Exception('Value cannot be negative.');
        } else {
            $this->timeOfDay = $timeOfDay;
        }

        if ($baseRate < self::MIN_RATE) {
            throw new Exception('Base rate below minimum.');
        } else {
            $this->baseRate = $baseRate;
        }

        $dateArr = explode('/', $driverDateOfBirth);

        if (count($dateArr) == 3) {
            if ((checkdate($dateArr[0], $dateArr[1], $dateArr[2])) !== true) {
                throw new Exception('Invalid date, please use mm/dd/yyyy.');
            }
        } else {
            throw new Exception('Invalid date formatting, please use simple mm/dd/yyyy.');
        }

        $this->dob = $driverDateOfBirth;
        $this->miles = 0;

    }

    /**
    * @param int $miles
    * @return bool
    */
    public function addMilage(int $miles): bool
    {
        $this->miles += $miles;
        return true;
    }

    /**
    * @return float
    * @throws Exception
    */
    public function getRate(): float
    {
        $dynamicRate = $this->miles * self::MILE_RATE;
        $totalRate = $dynamicRate + $this->baseRate;

        if (is_numeric($totalRate)) {
            return $totalRate;
        } else {
            throw new Exception('Invalid rate output.');
        }
    }

}

class TaxiMeter1
{
    const MIN_RATE = 2.50;
    const SECONDS_IN_DAY = 60 * 60 * 24;
    const MILE_RATE = 0.2;

    
    private $timeOfDay;
    private $baseRate;
    private $miles;

    /**
    * TaxiMeter constructor.
    * @param int $timeOfDay
    * @param float $baseRate
    * @param string $driverDateOfBirth
    * @throws Exception
    */
    public function __construct(int $timeOfDay, float $baseRate, string $driverDateOfBirth)
    {
        $this->setTimeOfDay($timeOfDay);
        $this->setBaseRate($baseRate);
        $this->validateDriverDateOfBirth($driverDateOfBirth);
        $this->miles = 0;
    }
    /**
    * Set timeOfDay class variable.
    * Only providing it doesn't exceed the maximum seconds in a day (constsecondsInDay) and is greater than 0.
    * @param $timeOfDay
    * @return bool
    * @throws Exception
    */
    private function setTimeOfDay($timeOfDay): bool
    {
        if ($timeOfDay > self::SECONDS_IN_DAY) {
            throw new Exception('There can only be ' . self::SECONDS_IN_DAY . '
            seconds in a day.');
        } else if ($timeOfDay < 0) {
            throw new Exception('Value cannot be negative.');
        } else {
            $this->timeOfDay = $timeOfDay;
            return true;
        }
    }

    /**
    * Sets the base rate variable providing it's over the MIN_RATE class constant.
    * @param $baseRate
    * @return bool
    * @throws Exception
    */
    private function setBaseRate($baseRate): bool
    {
        if ($baseRate < self::MIN_RATE) {
            throw new Exception('Base rate below minimum.');
        } else {
            $this->baseRate = $baseRate;
            return true;
        }
    }

    /**
    * Validates
    * @param $driverDateOfBirth
    * @return bool
    * @throws Exception
    */
    private function validateDriverDateOfBirth($driverDateOfBirth): bool
    {
        $dateArr = explode('/', $driverDateOfBirth);

        if (count($dateArr) == 3) {
            if ((checkdate($dateArr[0], $dateArr[1], $dateArr[2])) !== true) {
                throw new Exception('Invalid date, please use mm/dd/yyyy.');
            }
        } else {
            throw new Exception('Invalid date formatting, please use simple mm/dd/yyyy.');
        }

        return true;
    }

    /**
    * Adds given milage to the milage class variable.
    * @param int $miles
    * @return bool
    */
    public function addMilage(int $miles): bool
    {
        $this->miles += $miles;
        return true;
    }

    /**
    * Calculates rate of trip.
    * Times class constant mileRate against the current milage in miles class variables and adds the base rate.
    * @return float
    * @throws Exception
    */
    public function getRate(): float
    {
        $dynamicRate = $this->miles * self::MILE_RATE;
        $totalRate = $dynamicRate + $this->baseRate;
            
        if (is_numeric($totalRate)) {
            return $totalRate;
        } else {
            throw new Exception('Invalid rate output.');
        }
        
    }

}

