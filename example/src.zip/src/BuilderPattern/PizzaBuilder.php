<?php

class Pizza_tmp
{
    private $size;
    private $cheese;
    private $pepperoni;
    private $bacon;

    public function __construct($size, $cheese, $pepperoni, $bacon)
    {
        $this->size = $size;
        $this->cheese = $cheese;
        $this->pepperoni = $pepperoni;
        $this->bacon = $bacon;
    }

    public function show()
    {
        $recipe = $this->size . " inch pizza with the following toppings: ";
        $recipe .= $this->cheese ? "cheese, " : "";
        $recipe .= $this->pepperoni ? "pepperoni, " : "";
        $recipe .= $this->bacon ? "bacon, " : "";
        return $recipe;
    }
}

// Lập trình oop là lập trình theo hướng tư nhiên, Pizza_tmp hiện cái này vẫn đang chưa tốt vì sao chưa tốt


$pizza1 = new Pizza_tmp('m', true, false, 'yes');
$pizza2 = new Pizza_tmp('l', true, false, 'yes');


class Pizza
{
    private $size;
    private $cheese;
    private $pepperoni;
    private $bacon;

    public function __construct(PizzaBuilder $builder)
    {
        $this->size = $builder->size;
        $this->cheese = $builder->cheese;
        $this->pepperoni = $builder->pepperoni;
        $this->bacon = $builder->bacon;
    }

    public function show()
    {
        $recipe = $this->size . " inch pizza with the following toppings: ";
        $recipe .= $this->cheese ? "cheese, " : "";
        $recipe .= $this->pepperoni ? "pepperoni, " : "";
        $recipe .= $this->bacon ? "bacon, " : "";
        return $recipe;
    }
}


class PizzaBuilder
{

    public $size;
    public $cheese;
    public $pepperoni;
    public $bacon;

    public function __construct(int $size)
    {
        $this->size = $size;
    }

    public function cheese(bool $present): PizzaBuilder
    {
        $this->cheese = $present;
        return $this;
    }

    public function pepperoni(bool $present): PizzaBuilder
    {
        $this->pepperoni = $present;
        return $this;
    }

    public function bacon(bool $present): PizzaBuilder
    {
        $this->bacon = $present;
        return $this;
    }

    public function build()
    {
        return $this;
    }


}


$pizzaRecipe = (new PizzaBuilder(9))
->cheese(true)
->pepperoni(true)
->bacon(true)
->build();



$order = new Pizza($pizzaRecipe);