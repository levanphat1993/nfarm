<?php

namespace Src;

class Book
{
    public function __construct()
    {
        echo "Hello world!";
    }
}