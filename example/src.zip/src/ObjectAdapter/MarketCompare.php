<?php

interface MarketCompare
{
    public function __construct(float $limit, float $excess);
    
    public function getAnnualPremium(); // Nhận phí bảo hiểm hàng năm
    public function getMonthlyPremium(); // Nhận phí bảo hiểm hàng tháng
}