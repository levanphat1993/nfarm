<?php

class Insurance
{

    private $limit;
    private $excess;

    public function __construct(float $limit, float $excess)
    {
        if ($excess >= $limit) {
            throw New Exception('Excess must be less than premium.');
        }

        $this->limit = $limit;
        $this->excess = $excess;
    }

    /**
     * Monthly Premium
     *
     * @return float
     */
    public function monthlyPremium(): float // Bảo hiểm hàng tháng
    {
        return ($this->limit-$this->excess)/200;
    }

    /**
     * Annual Premium
     *
     * @return float
     */
    public function annualPremium(): float // Phí bảo hiểm hàng năm
    {
        return $this->monthlyPremium()*11.5;
    }
}