<?php

class Student
{
    public $name;
    public $year;
    public $grade;

    public function setName(string $name)
    {
        $this->name = $name;
    }

    public function setYear(int $year)
    {
        $this->year = $year;
    }

    public function setGrade(string $grade)
    {
        $this->grade = $grade;
    }
}

$prototypeStudent = new Student();
$prototypeStudent->setName('Dave');
$prototypeStudent->setYear(2);
$prototypeStudent->setGrade('A*');

$theLesserChild = clone $prototypeStudent;
$theLesserChild->setName('Mike');
$theLesserChild->setGrade('B');

$theChildProdigy->danceSkills = "Outstanding";
$theChildProdigy->dance = function (string $style) {
return "Dancing $style style.";
};