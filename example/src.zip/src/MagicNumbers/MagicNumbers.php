<?php

class MagicNumbers
{

    const minRate = 2.50;
    const secondsInDay = 60 * 60 * 24;
    const mileRate = 0.2;

}



