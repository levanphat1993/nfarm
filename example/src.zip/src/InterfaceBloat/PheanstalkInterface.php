<?php

namespace Src\InterfaceBloat;

class Connection
{
    // TODO
}

interface PheanstalkInterface
{
    const DEFAULT_PORT = 11300;
    const DEFAULT_DELAY = 0;
    const DEFAULT_PRIORITY = 1024;
    const DEFAULT_TTR = 60;
    const DEFAULT_TUBE = 'default';


    public function setConnection(Connection $connection);
    public function getConnection();
    public function bury($job, $priority = self::DEFAULT_PRIORITY);
    public function delete($job);
    public function ignore($tube);
    public function kick($max);
    public function kickJob($job);
    public function listTubes();
    public function listTubesWatched($askServer = false);
    public function listTubeUsed($askServer = false);
    public function pauseTube($tube, $delay);
    public function resumeTube($tube);
    public function peek($jobId);
    public function peekReady($tube = null);
    public function peekDelayed($tube = null);
    public function peekBuried($tube = null);
    public function put($data, $priority = self::DEFAULT_PRIORITY, $delay = self::DEFAULT_DELAY, $ttr = self::DEFAULT_TTR);
    public function putInTube($tube, $data, $priority = self::DEFAULT_PRIORITY, $delay = self::DEFAULT_DELAY, $ttr = self::DEFAULT_TTR);
    public function release($job, $priority = self::DEFAULT_PRIORITY, $delay = self::DEFAULT_DELAY);
    public function reserve($timeout = null);
    public function reserveFromTube($tube, $timeout = null);
    public function statsJob($job);
    public function statsTube($tube);
    public function stats();
    public function touch($job);
    public function useTube($tube);
    public function watch($tube);
    public function watchOnly($tube);
}